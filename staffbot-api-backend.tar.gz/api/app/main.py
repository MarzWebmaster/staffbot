from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse

from app.config import get_settings
from app.database import init_db

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    try:
        await init_db()
        print("[StaffBot API] Database tables initialized")
    except Exception as e:
        print(f"[StaffBot API] DB init warning: {e}")
    yield
    # Shutdown
    print("[StaffBot API] Shutting down")


app = FastAPI(
    title="StaffBot.my API",
    version="1.0.0",
    description="Digital Employee as a Service (DEaaS) — Backend API",
    lifespan=lifespan,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def root():
    return RedirectResponse(url="/docs")


@app.get("/api/v1/health")
async def health_check():
    return {
        "status": "ok",
        "version": "1.0.0",
        "service": "StaffBot.my API",
    }


# Import and register routers
from app.routers import auth, clients, subscriptions, containers, webhooks, notifications
from app.routers.admin import dashboard, packages, users, settings as admin_settings

app.include_router(auth.router, prefix="/api/v1/auth", tags=["Authentication"])
app.include_router(clients.router, prefix="/api/v1/clients", tags=["Clients"])
app.include_router(subscriptions.router, prefix="/api/v1/subscriptions", tags=["Subscriptions"])
app.include_router(containers.router, prefix="/api/v1/containers", tags=["Containers"])
app.include_router(webhooks.router, prefix="/api/v1/webhooks", tags=["Webhooks"])
app.include_router(notifications.router, prefix="/api/v1/notifications", tags=["Notifications"])
app.include_router(dashboard.router, prefix="/api/v1/admin", tags=["Admin"])
app.include_router(packages.router, prefix="/api/v1/admin/packages", tags=["Admin Packages"])
app.include_router(users.router, prefix="/api/v1/admin/users", tags=["Admin Users"])
app.include_router(admin_settings.router, prefix="/api/v1/admin/settings", tags=["Admin Settings"])

"""
Admin dashboard router — overview, stats, system health.
"""
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.database import get_db
from app.models.client import Client
from app.models.subscription import Subscription
from app.models.container import Container
from app.schemas.admin import DashboardStats, SystemHealth
from app.middleware.auth import get_current_admin
from app.services.server_b_service import ServerBService

router = APIRouter()


@router.get("/dashboard", response_model=DashboardStats)
async def get_dashboard_stats(
    admin: Client = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    """Get dashboard overview statistics."""
    # Total users
    total_result = await db.execute(select(func.count(Client.id)))
    total_users = total_result.scalar() or 0

    # Active users
    active_result = await db.execute(
        select(func.count(Client.id)).where(Client.status == "active")
    )
    active_users = active_result.scalar() or 0

    # Active containers
    container_result = await db.execute(
        select(func.count(Container.id)).where(Container.status == "running")
    )
    active_containers = container_result.scalar() or 0

    # Pending deployments
    pending_result = await db.execute(
        select(func.count(Client.id)).where(Client.status == "pending")
    )
    pending_deployments = pending_result.scalar() or 0

    # Total revenue (sum of subscription managed_tokens * rate or package prices)
    # For MVP, count active subscriptions with packages
    revenue_result = await db.execute(
        select(func.count(Subscription.id)).where(Subscription.status == "active")
    )
    # Simplified: estimate from active subs
    total_revenue = 0.0

    return DashboardStats(
        total_users=total_users,
        active_users=active_users,
        total_revenue=total_revenue,
        active_containers=active_containers,
        pending_deployments=pending_deployments,
        monthly_revenue=[{"month": "May 2026", "amount": 0}],  # Placeholder
    )


@router.get("/health", response_model=SystemHealth)
async def get_system_health(
    admin: Client = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    """Get system health status."""
    # Check DB
    db_status = "ok"
    try:
        await db.execute(select(func.count(Client.id)).limit(1))
    except Exception:
        db_status = "error"

    # Check Server B
    try:
        b_health = await ServerBService.health_check()
        server_b_status = b_health.get("status", "unknown")
    except Exception:
        server_b_status = "unreachable"

    return SystemHealth(
        api_status="ok",
        db_status=db_status,
        server_b_status=server_b_status,
        uptime=0.0,  # TODO: track app start time
    )

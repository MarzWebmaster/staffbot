"""
Admin routers package.

Sub-modules:
- dashboard.py - Overview stats, system health
- packages.py - Package CRUD
- users.py - User management
- settings.py - System settings
"""
